<template>
  <div>
    <div class="container">
      <div class="row justify-content-center">
        <router-views></router-views>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  name: "HomeComponent",
};
</script>