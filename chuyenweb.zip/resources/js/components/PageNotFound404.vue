<template>
    <div>
        <h1>Page not found 404</h1>
    </div>
</template>