<?php $__env->startSection('Title', 'Danh sách bài viết - Chuyên WEB'); ?>
<?php $__env->startSection('Noidung'); ?>
<div class="container">
    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="col-md-4 my-2">
        <a href="/<?php echo e($d->post_slug); ?>" class="">
            <h3><?php echo e($d->post_title); ?></h3>
            <img src="<?php echo e($d->post_img); ?>">
            <p><?php echo e($d->post_metakey); ?></p>
        </a>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('Template\home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Website\web-project\chuyenweb\resources\views/template/posts/index.blade.php ENDPATH**/ ?>