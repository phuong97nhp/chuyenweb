<?php $__env->startSection('Title', 'Thư viên hình ảnh -  Chuyên WEB'); ?>
<?php $__env->startSection('Noidung'); ?>

<h1>Hien thi QR Codes boi Stdio</h1>
<p>
	<div id="id_qrcode"></div>
</p>

<?php $__env->stopSection(); ?>

<script>
	var qrcode = new QRCode("id_qrcode", {
		text: <?php echo e($code); ?>,
		width:100,
		height:100,
		colorDark:"#000000",
		colorLight:"#ffffff",
		correctLevel:QRCode.CorrectLevel.H
	});
</script>
<?php echo $__env->make('CWadmin\home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Website\web-project\chuyenwebcore\resources\views/CWadmin/layout/posts/edit.blade.php ENDPATH**/ ?>