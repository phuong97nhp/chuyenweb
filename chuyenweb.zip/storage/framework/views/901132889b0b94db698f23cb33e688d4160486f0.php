<!-- begin:: Footer -->
<div class="kt-footer  kt-grid__item kt-grid kt-grid--desktop kt-grid--ver-desktop" id="kt_footer">
 <div class="kt-container  kt-container--fluid ">
  <div class="kt-footer__copyright">
   2020&nbsp;&copy;&nbsp;<a href="http://chuyenweb.com/" target="_blank" class="kt-link">ChuyenWEB.com</a>
 </div>
 <div class="kt-footer__menu">
   <a href="http://chuyenweb.com/gioi-thieu" target="_blank" class="kt-footer__menu-link kt-link">Giới thiệu</a>
   <a href="http://chuyenweb.com/lien-he" target="_blank" class="kt-footer__menu-link kt-link">Liên hệ</a>
   <a href="http://facebook.com/phuong97nhp" target="_blank" class="kt-footer__menu-link kt-link">Hỗ trợ</a>
 </div>
</div>
</div>
<!-- end:: Footer -->	<?php /**PATH D:\Website\web-project\chuyenwebcore\resources\views/CWadmin/modules/footer.blade.php ENDPATH**/ ?>