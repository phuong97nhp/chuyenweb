<?php $__env->startSection('Title', 'Trang chủ -  Chuyên WEB'); ?>
<?php $__env->startSection('Noidung'); ?>
hello
<?php $__env->stopSection(); ?>
<?php echo $__env->make('CWadmin\home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Website\web-project\chuyenwebcore\resources\views/CWadmin/layout/Images/index.blade.php ENDPATH**/ ?>